package jm.edu.utech.helpdesk.server.dto;

public record TicketRequest(String subject, String description, String priority, String submittedBy) {}
