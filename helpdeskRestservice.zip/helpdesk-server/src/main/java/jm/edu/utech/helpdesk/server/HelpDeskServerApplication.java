package jm.edu.utech.helpdesk.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//main application
@SpringBootApplication
public class HelpDeskServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelpDeskServerApplication.class, args);
    }
}
