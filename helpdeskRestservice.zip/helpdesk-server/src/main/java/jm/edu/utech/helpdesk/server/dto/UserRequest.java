package jm.edu.utech.helpdesk.server.dto;

// admin adding a user, password is optional
public record UserRequest(String username, String role, String password) {}
