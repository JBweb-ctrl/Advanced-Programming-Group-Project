package jm.edu.utech.helpdesk.server.service;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import org.springframework.stereotype.Service;
import jm.edu.utech.helpdesk.server.dto.TicketSearch;
import jm.edu.utech.helpdesk.server.model.Comment;
import jm.edu.utech.helpdesk.server.model.Ticket;

//hold the tickets and all the ticket logic
@Service
public class TicketService {

    public static final List<String> STATUSES =
            List.of("NEW", "ASSIGNED", "IN_PROGRESS", "PENDING", "RESOLVED", "CLOSED", "REOPENED");

    private final List<Ticket> tickets = new ArrayList<>();
    private long nextId = 1;

    public TicketService() {
        //same demo tickets the GUI had
        seed("Wi-Fi down in Block A", "Wi-Fi drops every few minutes.", "HIGH", "ASSIGNED", "tech", "student1");
        seed("Projector not working", "Projector in Room 47C-2 shows no signal.", "MEDIUM", "ASSIGNED", "tech", "student1");
        seed("Cannot reset password", "Reset email never arrives.", "LOW", "IN_PROGRESS", "tech", "student1");
        seed("Cannot access student portal", "Portal shows an error page.", "MEDIUM", "NEW", null, "student1");
    }

    private void seed(String subject, String description, String priority,
                      String status, String technician, String submittedBy) {
        Ticket t = addTicket(subject, description, priority, submittedBy);
        t.setStatus(status);
        t.setAssignedTechnician(technician);
    }

    public boolean isValidStatus(String status) {
        return STATUSES.contains(status);
    }

    public synchronized List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets);
    }

    //returns null if there is no ticket with that id
    public synchronized Ticket getTicketById(Long id) {
        for (Ticket t : tickets) {
            if (t.getId().equals(id)) {
                return t;
            }
        }
        return null;
    }

    public synchronized List<Ticket> getTicketsByUser(String username) {
        List<Ticket> results = new ArrayList<>();
        for (Ticket t : tickets) {
            if (username.equalsIgnoreCase(t.getSubmittedBy())) {
                results.add(t);
            }
        }
        return results;
    }

    public synchronized List<Ticket> getTicketsByTechnician(String technician) {
        List<Ticket> results = new ArrayList<>();
        for (Ticket t : tickets) {
            if (technician.equalsIgnoreCase(t.getAssignedTechnician())) {
                results.add(t);
            }
        }
        return results;
    }

    public synchronized boolean hasTicketsFor(String technician) {
        return !getTicketsByTechnician(technician).isEmpty();
    }

    public synchronized Ticket addTicket(String subject, String description, String priority, String submittedBy) {
        Ticket ticket = new Ticket();
        ticket.setId(nextId++);
        ticket.setSubject(subject);
        ticket.setDescription(description);
        ticket.setPriority(priority);
        ticket.setSubmittedBy(submittedBy);
        ticket.setStatus("NEW");
        ticket.setCreationDate(LocalDate.now().toString());
        ticket.setCreatedAt(LocalDateTime.now());
        tickets.add(ticket);
        return ticket;
    }

    public synchronized Ticket updateTicket(Long id, String subject, String description, String priority) {
        Ticket ticket = getTicketById(id);
        if (ticket == null) {
            return null;
        }
        ticket.setSubject(subject);
        ticket.setDescription(description);
        ticket.setPriority(priority);
        return ticket;
    }

    public synchronized Ticket assignTicket(Long id, String technician) {
        Ticket ticket = getTicketById(id);
        if (ticket == null) {
            return null;
        }
        ticket.setAssignedTechnician(technician);
        ticket.setStatus("ASSIGNED");
        return ticket;
    }

    public synchronized Ticket updateStatus(Long id, String status) {
        Ticket ticket = getTicketById(id);
        if (ticket == null) {
            return null;
        }
        ticket.setStatus(status);
        if (status.equals("RESOLVED")) {
            ticket.setResolvedAt(LocalDateTime.now());
        }
        return ticket;
    }

    public synchronized Ticket resolveTicket(Long id, String resolutionNotes) {
        Ticket ticket = getTicketById(id);
        if (ticket == null) {
            return null;
        }
        ticket.setResolutionNotes(resolutionNotes);
        ticket.setStatus("RESOLVED");
        ticket.setResolvedAt(LocalDateTime.now());
        return ticket;
    }

    public synchronized Ticket closeTicket(Long id) {
        return updateStatus(id, "CLOSED");
    }

    public synchronized Ticket reopenTicket(Long id) {
        return updateStatus(id, "REOPENED");
    }

    public synchronized Comment addComment(Long id, String author, String text) {
        Ticket ticket = getTicketById(id);
        if (ticket == null) {
            return null;
        }
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        Comment comment = new Comment(author, text, date);
        ticket.getComments().add(comment);
        return comment;
    }

    public synchronized List<Ticket> searchTickets(TicketSearch search) {
        String id = valueOrEmpty(search.id());
        String user = valueOrEmpty(search.user());
        String technician = valueOrEmpty(search.technician());
        String status = valueOrEmpty(search.status());
        String priority = valueOrEmpty(search.priority());
        String fromDate = valueOrEmpty(search.fromDate());
        String toDate = valueOrEmpty(search.toDate());

        List<Ticket> results = new ArrayList<>();

        for (Ticket t : tickets) {
            if (!id.isEmpty() && !String.valueOf(t.getId()).equals(id)) {
                continue;
            }
            if (!user.isEmpty() && (t.getSubmittedBy() == null
                    || !t.getSubmittedBy().toLowerCase().contains(user.toLowerCase()))) {
                continue;
            }
            if (!technician.isEmpty() && !technician.equalsIgnoreCase(t.getAssignedTechnician())) {
                continue;
            }
            if (!status.isEmpty() && !status.equals(t.getStatus())) {
                continue;
            }
            if (!priority.isEmpty() && !priority.equals(t.getPriority())) {
                continue;
            }
            if (!fromDate.isEmpty() && t.getCreationDate().compareTo(fromDate) < 0) {
                continue;
            }
            if (!toDate.isEmpty() && t.getCreationDate().compareTo(toDate) > 0) {
                continue;
            }
            results.add(t);
        }
        return results;
    }

    private String valueOrEmpty(String value) {
        return value == null ? "" : value.trim();
    }
}
