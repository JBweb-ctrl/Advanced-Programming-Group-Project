package jm.edu.utech.helpdesk.server.dto;

public record PasswordRequest(String currentPassword, String newPassword) {}
