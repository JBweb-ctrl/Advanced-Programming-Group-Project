package jm.edu.utech.helpdesk.server.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
//class cause records cant be modified and this is modified
// a student/staff member or admin
public class User {

    private String username;
    private String role;
    private String password;

    public User(String username, String role, String password) {
        this.username = username;
        this.role = role;
        this.password = password;
    }

    public String getUsername() {
		return username;
	}

	public String getRole() {
		return role;
	}


	// password is never sent back to the client
    @JsonIgnore
	public String getPassword() {
		return password;
	}
    
	public void setPassword(String password) {
		this.password = password;
	}

}
