package jm.edu.utech.helpdesk.server.dto;

public record StatusRequest(String status) {}
