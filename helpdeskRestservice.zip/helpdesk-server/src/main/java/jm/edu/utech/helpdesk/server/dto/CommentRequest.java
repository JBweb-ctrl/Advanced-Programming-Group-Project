package jm.edu.utech.helpdesk.server.dto;

public record CommentRequest(String author, String text) {}
