package jm.edu.utech.helpdesk.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jm.edu.utech.helpdesk.server.dto.LoginRequest;
import jm.edu.utech.helpdesk.server.dto.LoginResponse;
import jm.edu.utech.helpdesk.server.dto.PasswordRequest;
import jm.edu.utech.helpdesk.server.dto.UserRequest;
import jm.edu.utech.helpdesk.server.model.User;
import jm.edu.utech.helpdesk.server.service.UserService;

//handles login, register, logout, add and remove user, and change password
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService service;

    //constructor injection
    @Autowired
    public UserController(UserService service) {
        this.service = service;
    }

    //GET users
    @GetMapping
    public List<User> getAllUsers() {
        return service.getAllUsers();
    }

    //admin adds a user
    @PostMapping
    public ResponseEntity<User> addUser(@RequestBody UserRequest request) {
        if (isBlank(request.username()) || isBlank(request.role())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        User created = service.addUser(request.username().trim(), request.role(), request.password());
        if (created == null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();   // username already exists
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    //register account
    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody LoginRequest request) {
        if (isBlank(request.username()) || request.password() == null || request.password().length() < 6) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        User created = service.addUser(request.username().trim(), "Student/Staff", request.password());
        if (created == null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    //login users
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        LoginResponse result = service.login(request.username(), request.password());
        if (result == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.ok(result);
    }

    //the client goes back to login
    @PostMapping("/logout")
    public ResponseEntity<Void> logout() {
        return ResponseEntity.noContent().build();
    }

    //change and make new password
    @PutMapping("/{username}/password")
    public ResponseEntity<Void> changePassword(@PathVariable("username") String username,
                                               @RequestBody PasswordRequest request) {
        if (request.newPassword() == null || request.newPassword().length() < 6) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (service.changePassword(username, request.currentPassword(), request.newPassword())) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    //delete user
    @DeleteMapping("/{username}")
    public ResponseEntity<Void> removeUser(@PathVariable("username") String username) {
        if (service.removeUser(username)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
