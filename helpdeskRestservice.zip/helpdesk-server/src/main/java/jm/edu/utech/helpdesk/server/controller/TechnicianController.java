package jm.edu.utech.helpdesk.server.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jm.edu.utech.helpdesk.server.dto.TechnicianRequest;
import jm.edu.utech.helpdesk.server.model.Technician;
import jm.edu.utech.helpdesk.server.model.Ticket;
import jm.edu.utech.helpdesk.server.service.TechnicianService;
import jm.edu.utech.helpdesk.server.service.TicketService;
import jm.edu.utech.helpdesk.server.service.UserService;
//lists adds and removes tech and returns a tech ticket
@RestController
@RequestMapping("/api/technicians")
public class TechnicianController {

    private final TechnicianService technicianService;
    private final UserService userService;
    private final TicketService ticketService;

    @Autowired
    public TechnicianController(TechnicianService technicianService, UserService userService, TicketService ticketService) {
        this.technicianService = technicianService;
        this.userService = userService;
        this.ticketService = ticketService;
    }
    //CRUD
    //GET a tech
    @GetMapping
    public List<Technician> getAllTechnicians() {
        return technicianService.getAllTechnicians();
    }

    //POST a tech
    @PostMapping
    public ResponseEntity<Technician> addTechnician(@RequestBody TechnicianRequest request) {
        if (request.username() == null || request.username().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        String username = request.username().trim();
        if (userService.usernameTaken(username)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        Technician created = technicianService.addTechnician(username);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    //DELETE a tech
    @DeleteMapping("/{username}")
    public ResponseEntity<Void> removeTechnician(@PathVariable("username") String username) {
        if (ticketService.hasTicketsFor(username)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();   // still has tickets assigned
        }
        if (technicianService.removeTechnician(username)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    //GET tech tickets
    @GetMapping("/{username}/tickets")
    public ResponseEntity<List<Ticket>> getAssignedTickets(@PathVariable("username") String username) {
        if (technicianService.findTechnician(username) == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(ticketService.getTicketsByTechnician(username));
    }
}
