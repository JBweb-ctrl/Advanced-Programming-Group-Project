package jm.edu.utech.helpdesk.server.dto;

// the report text, the GUI puts it straight in the result area
public record ReportResponse(String report) {}
