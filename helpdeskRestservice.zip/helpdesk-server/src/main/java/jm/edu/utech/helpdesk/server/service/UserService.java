package jm.edu.utech.helpdesk.server.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jm.edu.utech.helpdesk.server.dto.LoginResponse;
import jm.edu.utech.helpdesk.server.model.Technician;
import jm.edu.utech.helpdesk.server.model.User;

//holds the users handles login and password changes and checks technicians too
@Service
public class UserService {

    private static final String DEFAULT_PASSWORD = "password123";

    private final List<User> users = new ArrayList<>();
    private final TechnicianService technicianService;

    //technicians can log in too so this service needs the technician service
    @Autowired
    public UserService(TechnicianService technicianService) {
        this.technicianService = technicianService;

        //same demo users as GUI
        users.add(new User("student1", "Student/Staff", DEFAULT_PASSWORD));
        users.add(new User("abc", "Student/Staff", DEFAULT_PASSWORD));
        users.add(new User("admin", "Administrator", DEFAULT_PASSWORD));
    }

    public synchronized List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    public synchronized User findUser(String username) {
        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                return u;
            }
        }
        return null;
    }

    //a username cant be used by both a user and a technician
    public synchronized boolean usernameTaken(String username) {
        return findUser(username) != null || technicianService.findTechnician(username) != null;
    }

    //returns null if the username is already taken
    public synchronized User addUser(String username, String role, String password) {
        if (usernameTaken(username)) {
            return null;
        }
        if (password == null || password.isEmpty()) {
            password = DEFAULT_PASSWORD;
        }
        User user = new User(username, role, password);
        users.add(user);
        return user;
    }

    //returns null if the username or password is wrong
    public synchronized LoginResponse login(String username, String password) {
        User user = findUser(username);
        if (user != null && user.getPassword().equals(password)) {
            return new LoginResponse(user.getUsername(), user.getRole());
        }
        Technician tech = technicianService.findTechnician(username);
        if (tech != null && tech.getPassword().equals(password)) {
            return new LoginResponse(tech.getUsername(), "Technician");
        }
        return null;
    }

    //returns false if the user dont exist or current password is wrong
    public synchronized boolean changePassword(String username, String currentPassword, String newPassword) {
        User user = findUser(username);
        if (user != null) {
            if (!user.getPassword().equals(currentPassword)) {
                return false;
            }
            user.setPassword(newPassword);
            return true;
        }
        Technician tech = technicianService.findTechnician(username);
        if (tech != null) {
            if (!tech.getPassword().equals(currentPassword)) {
                return false;
            }
            tech.setPassword(newPassword);
            return true;
        }
        return false;
    }

    public synchronized boolean removeUser(String username) {
        return users.removeIf(u -> u.getUsername().equalsIgnoreCase(username));
    }
}
