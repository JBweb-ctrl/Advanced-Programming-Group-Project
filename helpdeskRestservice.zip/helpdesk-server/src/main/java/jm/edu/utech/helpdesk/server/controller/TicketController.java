package jm.edu.utech.helpdesk.server.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jm.edu.utech.helpdesk.server.dto.AssignRequest;
import jm.edu.utech.helpdesk.server.dto.CommentRequest;
import jm.edu.utech.helpdesk.server.dto.ResolveRequest;
import jm.edu.utech.helpdesk.server.dto.StatusRequest;
import jm.edu.utech.helpdesk.server.dto.TicketRequest;
import jm.edu.utech.helpdesk.server.dto.TicketSearch;
import jm.edu.utech.helpdesk.server.model.Comment;
import jm.edu.utech.helpdesk.server.model.Ticket;
import jm.edu.utech.helpdesk.server.service.TechnicianService;
import jm.edu.utech.helpdesk.server.service.TicketService;

//every ticket endpoint wiew, create, edit, assign, status, resolve, close, reopen, comment, search
//HttpStatus does the status codes
@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService service;
    private final TechnicianService technicianService;

    @Autowired
    public TicketController(TicketService service, TechnicianService technicianService) {
        this.service = service;
        this.technicianService = technicianService;
    }

    //GET tickets
    @GetMapping
    public List<Ticket> getAllTickets() {
        return service.getAllTickets();
    }

    //GET ticket by id 
    @GetMapping("/{id}")
    public ResponseEntity<Ticket> getTicketById(@PathVariable("id") Long id) {
        return reply(service.getTicketById(id));
    }

    //GET ticket by username
    @GetMapping("/user/{username}")
    public List<Ticket> getTicketsByUser(@PathVariable("username") String username) {
        return service.getTicketsByUser(username);
    }

    //POST tickets 
    @PostMapping
    public ResponseEntity<Ticket> addTicket(@RequestBody TicketRequest request) {
        if (isBlank(request.subject()) || isBlank(request.description())
                || isBlank(request.priority()) || isBlank(request.submittedBy())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Ticket created = service.addTicket(request.subject().trim(), request.description().trim(),
                request.priority(), request.submittedBy());
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    //ticket search
    @PostMapping("/search")
    public List<Ticket> searchTickets(@RequestBody TicketSearch search) {
        return service.searchTickets(search);
    }

    //to edit subject, description, priority
    @PutMapping("/{id}")
    public ResponseEntity<Ticket> updateTicket(@PathVariable("id") Long id, @RequestBody TicketRequest request) {
        if (isBlank(request.subject()) || isBlank(request.description()) || isBlank(request.priority())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        return reply(service.updateTicket(id, request.subject().trim(), request.description().trim(),
                request.priority()));
    }

    //PUT to assign ticket
    @PutMapping("/{id}/assign")
    public ResponseEntity<Ticket> assignTicket(@PathVariable("id") Long id, @RequestBody AssignRequest request) {
        if (isBlank(request.technician()) || technicianService.findTechnician(request.technician()) == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();   // not a real technician
        }
        return reply(service.assignTicket(id, technicianService.findTechnician(request.technician()).getUsername()));
    }

    //to change ticket status
    @PutMapping("/{id}/status")
    public ResponseEntity<Ticket> updateStatus(@PathVariable("id") Long id, @RequestBody StatusRequest request) {
        if (request.status() == null || !service.isValidStatus(request.status())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        return reply(service.updateStatus(id, request.status()));
    }

    //upade ticket to resolved
    @PutMapping("/{id}/resolve")
    public ResponseEntity<Ticket> resolveTicket(@PathVariable("id") Long id, @RequestBody ResolveRequest request) {
        if (isBlank(request.resolutionNotes())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        return reply(service.resolveTicket(id, request.resolutionNotes().trim()));
    }

    //to close ticket
    @PutMapping("/{id}/close")
    public ResponseEntity<Ticket> closeTicket(@PathVariable("id") Long id) {
        return reply(service.closeTicket(id));
    }

    //to reopen ticket
    @PutMapping("/{id}/reopen")
    public ResponseEntity<Ticket> reopenTicket(@PathVariable("id") Long id) {
        return reply(service.reopenTicket(id));
    }

    //edit ticket comments
    @PostMapping("/{id}/comments")
    public ResponseEntity<Comment> addComment(@PathVariable("id") Long id, @RequestBody CommentRequest request) {
        if (isBlank(request.author()) || isBlank(request.text())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Comment added = service.addComment(id, request.author(), request.text().trim());
        if (added == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(added);
    }

    // code 200 with the ticket or 404 error if not found
    private ResponseEntity<Ticket> reply(Ticket ticket) {
        if (ticket == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(ticket);
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
