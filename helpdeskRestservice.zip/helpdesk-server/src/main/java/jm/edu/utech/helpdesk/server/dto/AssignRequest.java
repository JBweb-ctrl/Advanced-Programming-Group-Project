package jm.edu.utech.helpdesk.server.dto;

public record AssignRequest(String technician) {}
