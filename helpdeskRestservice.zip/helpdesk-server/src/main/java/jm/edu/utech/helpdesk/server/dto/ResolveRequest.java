package jm.edu.utech.helpdesk.server.dto;

public record ResolveRequest(String resolutionNotes) {}
