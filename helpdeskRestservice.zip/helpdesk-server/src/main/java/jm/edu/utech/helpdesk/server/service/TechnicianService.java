package jm.edu.utech.helpdesk.server.service;
import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Service;

import jm.edu.utech.helpdesk.server.model.Technician;
//holds the technician list
@Service
public class TechnicianService {

    public static final String DEFAULT_PASSWORD = "password123";

    private final List<Technician> technicians = new ArrayList<>();

    public TechnicianService() {
        //same demo technicians as GUI
        technicians.add(new Technician("tech", DEFAULT_PASSWORD));
        technicians.add(new Technician("tech2", DEFAULT_PASSWORD));
    }

    public synchronized List<Technician> getAllTechnicians() {
        return new ArrayList<>(technicians);
    }

    public synchronized List<String> getTechnicianNames() {
        List<String> names = new ArrayList<>();
        for (Technician t : technicians) {
            names.add(t.getUsername());
        }
        return names;
    }

    // returns null if there is no technician with that username
    public synchronized Technician findTechnician(String username) {
        for (Technician t : technicians) {
            if (t.getUsername().equalsIgnoreCase(username)) {
                return t;
            }
        }
        return null;
    }

    public synchronized Technician addTechnician(String username) {
        Technician technician = new Technician(username, DEFAULT_PASSWORD);
        technicians.add(technician);
        return technician;
    }

    public synchronized boolean removeTechnician(String username) {
        return technicians.removeIf(t -> t.getUsername().equalsIgnoreCase(username));
    }
}
