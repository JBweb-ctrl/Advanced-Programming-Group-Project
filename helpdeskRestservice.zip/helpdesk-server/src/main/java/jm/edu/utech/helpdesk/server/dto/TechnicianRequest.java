package jm.edu.utech.helpdesk.server.dto;

public record TechnicianRequest(String username) {}
