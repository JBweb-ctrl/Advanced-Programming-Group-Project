package jm.edu.utech.helpdesk.server.dto;

// used for login and for register
public record LoginRequest(String username, String password) {}
