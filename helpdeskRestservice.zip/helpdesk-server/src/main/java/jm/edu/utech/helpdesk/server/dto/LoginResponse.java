package jm.edu.utech.helpdesk.server.dto;

// the GUI uses the role to decide which dashboard to open
public record LoginResponse(String username, String role) {}
