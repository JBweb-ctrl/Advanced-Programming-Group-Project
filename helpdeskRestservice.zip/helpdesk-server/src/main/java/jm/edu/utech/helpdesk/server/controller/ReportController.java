package jm.edu.utech.helpdesk.server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jm.edu.utech.helpdesk.server.dto.ReportResponse;
import jm.edu.utech.helpdesk.server.service.ReportService;
//REST endpoints for the 5 report endpoints
@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final ReportService service;

    @Autowired
    public ReportController(ReportService service) {
        this.service = service;
    }

    @GetMapping("/tickets-submitted")
    public ReportResponse ticketsSubmitted() {
        return new ReportResponse(service.ticketsSubmitted());
    }

    @GetMapping("/tickets-resolved")
    public ReportResponse ticketsResolved() {
        return new ReportResponse(service.ticketsResolved());
    }

    @GetMapping("/open-tickets")
    public ReportResponse openTickets() {
        return new ReportResponse(service.openTickets());
    }

    @GetMapping("/technician-workload")
    public ReportResponse technicianWorkload() {
        return new ReportResponse(service.technicianWorkload());
    }

    @GetMapping("/average-resolution-time")
    public ReportResponse averageResolutionTime() {
        return new ReportResponse(service.averageResolutionTime());
    }
}
