package jm.edu.utech.helpdesk.server.service;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jm.edu.utech.helpdesk.server.model.Ticket;

//builds the report text from the ticket and technician data
@Service
public class ReportService {

    private final TicketService ticketService;
    private final TechnicianService technicianService;

    @Autowired
    public ReportService(TicketService ticketService, TechnicianService technicianService) {
        this.ticketService = ticketService;
        this.technicianService = technicianService;
    }

    public String ticketsSubmitted() {
        List<Ticket> all = ticketService.getAllTickets();

        List<String> users = new ArrayList<>();
        for (Ticket t : all) {
            if (t.getSubmittedBy() != null && !users.contains(t.getSubmittedBy())) {
                users.add(t.getSubmittedBy());
            }
        }

        StringBuilder report = new StringBuilder("TICKETS SUBMITTED\nTotal: " + all.size() + "\n");
        for (String user : users) {
            int count = 0;
            for (Ticket t : all) {
                if (user.equals(t.getSubmittedBy())) {
                    count++;
                }
            }
            report.append(user).append(": ").append(count).append("\n");
        }
        return report.toString();
    }

    public String ticketsResolved() {
        StringBuilder lines = new StringBuilder();
        int count = 0;
        for (Ticket t : ticketService.getAllTickets()) {
            if (t.getStatus().equals("RESOLVED")) {
                count++;
                lines.append("#").append(t.getId()).append(" ").append(t.getSubject())
                     .append(" (").append(t.getAssignedTechnician()).append(")\n");
            }
        }
        return "TICKETS RESOLVED\nTotal: " + count + "\n" + lines;
    }

    public String openTickets() {
        StringBuilder lines = new StringBuilder();
        int count = 0;
        for (Ticket t : ticketService.getAllTickets()) {
            if (isOpen(t)) {
                count++;
                lines.append("#").append(t.getId()).append("  ").append(t.getSubject())
                     .append("  [").append(t.getStatus()).append("]\n");
            }
        }
        return "OPEN TICKETS\nTotal: " + count + "\n" + lines;
    }

    public String technicianWorkload() {
        List<Ticket> all = ticketService.getAllTickets();
        StringBuilder report = new StringBuilder("TECHNICIAN WORKLOAD\n");
        for (String technician : technicianService.getTechnicianNames()) {
            int open = 0;
            int total = 0;
            for (Ticket t : all) {
                if (technician.equalsIgnoreCase(t.getAssignedTechnician())) {
                    total++;
                    if (isOpen(t)) {
                        open++;
                    }
                }
            }
            report.append(technician).append(": ").append(open).append(" open & ")
                  .append(total).append(" assigned in total\n");
        }
        return report.toString();
    }

    public String averageResolutionTime() {
        long totalSeconds = 0;
        int count = 0;
        for (Ticket t : ticketService.getAllTickets()) {
            if (t.getStatus().equals("RESOLVED") && t.getCreatedAt() != null && t.getResolvedAt() != null) {
                totalSeconds += Duration.between(t.getCreatedAt(), t.getResolvedAt()).getSeconds();
                count++;
            }
        }
        if (count == 0) {
            return "AVERAGE RESOLUTION TIME\nNo resolved tickets yet.\n";
        }
        long avg = totalSeconds / count;
        return "AVERAGE RESOLUTION TIME\nResolved tickets: " + count + "\nAverage: "
                + (avg / 3600) + " hours " + ((avg % 3600) / 60) + " minutes\n";
    }

    private boolean isOpen(Ticket t) {
        return !t.getStatus().equals("RESOLVED") && !t.getStatus().equals("CLOSED");
    }
}
