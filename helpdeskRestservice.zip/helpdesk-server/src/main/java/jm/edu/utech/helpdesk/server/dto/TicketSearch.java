package jm.edu.utech.helpdesk.server.dto;

// every field is optional, empty means "any"
public record TicketSearch(String id, String user, String technician, String status,
                           String priority, String fromDate, String toDate) {}
