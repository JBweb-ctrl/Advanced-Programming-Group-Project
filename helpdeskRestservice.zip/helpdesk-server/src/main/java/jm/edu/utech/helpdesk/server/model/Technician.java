package jm.edu.utech.helpdesk.server.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
//class cause records cant be modified and this is modified
public class Technician {

    private String username;
    private String password;

    public Technician(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
		return username;
	}

	@JsonIgnore
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
