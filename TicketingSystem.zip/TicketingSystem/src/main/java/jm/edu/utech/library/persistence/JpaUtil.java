package jm.edu.utech.library.persistence;

public class JpaUtil {
   private static final EntityManagerFactory FACTORY =
		   Persistence.createEntityManagerFactory("libraryPU");
   
   public static EntityManager createEntityManager() {
	   return FACTORY.createEntityManager();
   }
   public static void close() {
	   if (FACTORY.isOpen()) FACTORY.close();
   }
   private JpaUtil() {}
}
