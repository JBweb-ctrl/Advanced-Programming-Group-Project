package jm.edu.utech.library.persistence;

import java.util.List;
import java.util.Optional;

import jm.edu.utech.library.model.Ticket;
import jm.edu.utech.library.model.User;

public class TicketRepository {
	 public Ticket save(Ticket ticket) {
	        EntityManager em = JpaUtil.createEntityManager();
	        EntityTransaction tx = em.getTransaction();

	        try {
	            tx.begin();
	            Ticket saved = ticket.getId() == null
	                ? persistNew(em, ticket) : em.merge(ticket);
	            tx.commit();
	            return saved;
	        } catch (RuntimeException ex) {
	            if (tx.isActive()) tx.rollback();
	            throw ex;
	        } finally {
	            em.close();
	        }
	    }

	    private Ticket persistNew(EntityManager em, Ticket ticket) {
	        em.persist(ticket);
	        return ticket;
	    }
	 public Optional<Ticket> findById(Long id) {
	     EntityManager em = JpaUtil.createEntityManager();
	     try {
	         return Optional.ofNullable(em.find(Ticket.class, id));
	     } finally {
	         em.close();
	     }
	 }

	 public List<Ticket> findAll() {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        return em.createQuery(
		                "select t from Ticket t order by t.type", Ticket.class)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}

		public List<Ticket> search(String text) {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        String pattern = "%" + text.trim().toLowerCase() + "%";
		        return em.createQuery(
		                "select t from Ticket t " +
		                "where lower(t.type) like :pattern " +
		                "or lower(t.description) like :pattern " +
		                "or cast (t.id as string) like :pattern " +
		                "or cast (t.user.id as string) like :pattern " +
		                "order by t.type", Ticket.class)
		                .setParameter("pattern", pattern)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}
		
		public List<Ticket> findByUserId(Long userId) {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        return em.createQuery(
		                "select t from Ticket t " +
		                "where t.user.id = :userId " +
		                "order by t.id", Ticket.class)
		                .setParameter("userId", userId)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}
	
		public List<Ticket> findByTechnicianId(Long technicianId) {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        return em.createQuery(
		                "select t from Ticket t " +
		                "where t.technician.id = :technicianId " +
		                "order by t.id", Ticket.class)
		                .setParameter("technicianId", technicianId)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}


	 public void delete(Long id) {
	     EntityManager em = JpaUtil.createEntityManager();
	     EntityTransaction tx = em.getTransaction();
	     try {
	         tx.begin();
	         Ticket managed = em.find(Ticket.class, id);
	         if (managed != null) em.remove(managed);
	         tx.commit();
	     } catch (RuntimeException ex) {
	         if (tx.isActive()) tx.rollback();

	         throw ex;
	     } finally {
	         em.close();
	     }
	 }
}
