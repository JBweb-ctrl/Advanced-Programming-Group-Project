package jm.edu.utech.library.model;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "technician")
public class Technician {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "technician_id")
	private Long id;
	
	@Column(nullable = false, length = 50)
	private String name;
	
	@Column(nullable =false, length =50)
	private String position;
	
	@Column(name = "phone_number",nullable= false, length =20)
	private String phoneNumber;
	
	@JsonIgnore
	@OneToMany(mappedBy = "technician")
	private List <Ticket> tickets = new ArrayList<>();
	
	protected Technician() {}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	public Technician(Long id, String name, String position, String phoneNumber) {
		super();
		this.id = id;
		this.name = name;
		this.position = position;
		this.phoneNumber = phoneNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}
