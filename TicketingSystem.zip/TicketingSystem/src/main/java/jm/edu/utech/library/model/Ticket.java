package jm.edu.utech.library.model;

import java.util.List;

@Entity
@Table(name = "ticket")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ticket_number")
	private Long id;
	
	@Column(nullable = false, length = 30)
	private String type;
	
	@Column(nullable =false, length =200)
	private String description;
	
	@ManyToOne(Optional = false)
	@JoinColumn(name ="user_id", nullable = false)
	private User user;
	
	@ManyToOne
	@JoinColumn(name ="technician_id")
	private Technician technician;
	
	 @JsonIgnore
	    @OneToMany(mappedBy = "ticket", cascade = CascadeType.ALL, orphanRemoval = true)
	    private List<Comment> comments = new ArrayList<>();
	    
	protected Ticket() {}


	public Ticket(Long id, String type, String description, User user , Technician technician) {
		super();
		this.id = id;
		this.type = type;
		this.description = description;
		this.user = user;
		this.technician = technician;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Technician getTechnician() {
		return technician;
	}


	public void setTechnician(Technician technician) {
		this.technician = technician;
	}


	public List<Comment> getComments() {
		return comments;
	}


	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}


	public void addComment(Comment comment) {
        comments.add(comment);
        comment.setTicket(this);
    }
	
}
