package jm.edu.utech.library.persistence;

import jm.edu.utech.library.model.User;

public class UserRepository {
    public User save(User user) {
        EntityManager em = JpaUtil.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();
            User saved = user.getId() == null
                ? persistNew(em, user) : em.merge(user);
            tx.commit();
            return saved;
        } catch (RuntimeException ex) {
            if (tx.isActive()) tx.rollback();
            throw ex;
        } finally {
            em.close();
        }
    }

    private User persistNew(EntityManager em, User user) {
        em.persist(user);
        return user;
    }
 public Optional<User> findById(Long id) {
     EntityManager em = JpaUtil.createEntityManager();
     try {
         return Optional.ofNullable(em.find(User.class, id));
     } finally {
         em.close();
     }
 }

 public List<User> findAll() {
	    EntityManager em = JpaUtil.createEntityManager();
	    try {
	        return em.createQuery(
	                "select u from User u order by u.name", User.class)
	                .getResultList();
	    } finally {
	        em.close();
	    }
	}

	public List<User> search(String text) {
	    EntityManager em = JpaUtil.createEntityManager();
	    try {
	        String pattern = "%" + text.trim().toLowerCase() + "%";
	        return em.createQuery(
	                "select u from User u " +
	                "where lower(u.name) like :pattern " +
	                "or lower(u.email) like :pattern " +
	                "or u.phoneNumber like :pattern " +
	                "order by u.name", User.class)
	                .setParameter("pattern", pattern)
	                .getResultList();
	    } finally {
	        em.close();
	    }
	}

 public void delete(Long id) {
     EntityManager em = JpaUtil.createEntityManager();
     EntityTransaction tx = em.getTransaction();
     try {
         tx.begin();
         User managed = em.find(User.class, id);
         if (managed != null) em.remove(managed);
         tx.commit();
     } catch (RuntimeException ex) {
         if (tx.isActive()) tx.rollback();

         throw ex;
     } finally {
         em.close();
     }
 }
}
