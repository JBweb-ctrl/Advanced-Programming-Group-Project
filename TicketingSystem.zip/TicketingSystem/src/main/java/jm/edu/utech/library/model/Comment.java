package jm.edu.utech.library.model;

@Entity
@Table(name = "comment")
public class Comment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "comment_id")
	private Long id;
	
	@ManyToOne(optional = false)
	@Column(name = "ticket_number", nullable = false)
	private Ticket ticket;
	
	@Column(nullable =false, length =1000)
	private String text;
	
	
	protected Comment() {}


	public Comment(Long id, Long ticketNumber, String text) {
		super();
		this.id = id;
		this.ticket = ticket;
		this.text = text;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Ticket getTicket() {
		return ticket;
	}


	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}


	public String getText() {
		return text;
	}

	 public Long getTicketNumber() {
		 return ticket == null ? null : ticket.getId();
		 }
	 


	public void setText(String text) {
		this.text = text;
	}

}
	