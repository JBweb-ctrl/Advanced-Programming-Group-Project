package jm.edu.utech.library.persistence;

import jm.edu.utech.library.model.Technician;

public class TechnicianRepository {
	 public Technician save(Technician technician) {
	        EntityManager em = JpaUtil.createEntityManager();
	        EntityTransaction tx = em.getTransaction();

	        try {
	            tx.begin();
	            Technician saved = technician.getId() == null
	                ? persistNew(em, technician) : em.merge(technician);
	            tx.commit();
	            return saved;
	        } catch (RuntimeException ex) {
	            if (tx.isActive()) tx.rollback();
	            throw ex;
	        } finally {
	            em.close();
	        }
	    }

	    private Technician persistNew(EntityManager em, Technician technician) {
	        em.persist(technician);
	        return technician;
	    }
	 public Optional<Technician> findById(Long id) {
	     EntityManager em = JpaUtil.createEntityManager();
	     try {
	         return Optional.ofNullable(em.find(Technician.class, id));
	     } finally {
	         em.close();
	     }
	 }

	 public List<Technician> findAll() {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        return em.createQuery(
		                "select t from Technician t order by t.name", Technician.class)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}

		public List<Technician> search(String text) {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        String pattern = "%" + text.trim().toLowerCase() + "%";
		        return em.createQuery(
		                "select t from Technician t " +
		                "where lower(t.name) like :pattern " +
		                "or lower(t.position) like :pattern " +
		                "or t.phoneNumber like :pattern " +
		                "order by t.name", Technician.class)
		                .setParameter("pattern", pattern)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}

	 public void delete(Long id) {
	     EntityManager em = JpaUtil.createEntityManager();
	     EntityTransaction tx = em.getTransaction();
	     try {
	         tx.begin();
	         Technician managed = em.find(Technician.class, id);
	         if (managed != null) em.remove(managed);
	         tx.commit();
	     } catch (RuntimeException ex) {
	         if (tx.isActive()) tx.rollback();

	         throw ex;
	     } finally {
	         em.close();
	     }
	 }
}
