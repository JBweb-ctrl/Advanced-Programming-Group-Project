package jm.edu.utech.helpdesk.controller;
import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.view.RegisterView;
import jm.edu.utech.helpdesk.service.TechnicianService;
import jm.edu.utech.helpdesk.service.UserService;
//handles the create account screen
public class RegisterController {
//the register screen the controller needs
	private final RegisterView view;

    public RegisterController(RegisterView view) {
        this.view = view;
        attachHandlers();
    }
  //whats happens when each button is pressed
    private void attachHandlers() {
    	//button to register and go to the register screen
        view.getRegisterButton().setOnAction(e -> handleRegister());
        //back button goes back to the login screen
        view.getBackButton().setOnAction(e -> SceneManager.showLogin());
    }
  //reads the info entered in the view and show error if something is wrong
    private void handleRegister() {
        String username = view.getUsernameField().getText().trim();
        String password = view.getPasswordField().getText();
        String confirm = view.getConfirmField().getText();

        view.getErrorLabel().setText("");
//checks for any errors and shows error message
        if (username.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            view.getErrorLabel().setText("Fill in all fields");
            return;
        }
        if (password.length() < 6) {
            view.getErrorLabel().setText("Password should be least 6 characters");
            return;
        }
        if (!password.equals(confirm)) {
            view.getErrorLabel().setText("Passwords do not match");
            return;
        }
        
   //Technician name is already taken
        //
        //
        //
        if (TechnicianService.getInstance().exists(username) || !UserService.getInstance().addUser(username, "Student/Staff")) {
        	AlertUtil.showError("Duplicate use account","That username already exists" );
        	return;
        }
        AlertUtil.showInfo("Register", "Account created for: " + username);
        SceneManager.showLogin();

        // Placeholder until the backend registration endpoint exists
        AlertUtil.showInfo("Register", "Account validated for: " + username);
        SceneManager.showLogin();
    }
}
