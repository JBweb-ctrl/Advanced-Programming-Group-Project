package jm.edu.utech.helpdesk.controller;
import jm.edu.utech.helpdesk.service.ReportService;
import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.view.ReportsView;

//reports screen the admin will see
public class ReportsController {

	private final ReportsView view;
	private final String username;
	
	private final ReportService service = ReportService.getInstance();
	
	public ReportsController(ReportsView view, String username) {
		this.view = view;
		this.username = username;
		attachHandlers();
	}
	//what happens when each button is pressed
	private void attachHandlers() {
		//generate a report once you choose what type of report to generate
		view.getGenerateButton().setOnAction(e -> handleGenerate());
		//go back to admin dashboard
		view.getBackButton().setOnAction(e -> SceneManager.showAdminDashboard(username));
	}
	//runs when the admin clicks generate 
	private void handleGenerate() {
		String report = view.getReportBox().getValue();
		
		if (report == null) {
			AlertUtil.showError("No report selected", "Select a report");
			return;
		}
		//checks wich report was picked in the dropdown option then it gets displayed
		//so if you choose "Tickets Submitted" its displayed the tickets submitted
		if (report.equalsIgnoreCase("Tickets Submitted")) {
            view.getResultArea().setText(service.ticketsSubmitted());
        } else if (report.equalsIgnoreCase("Tickets Resolved")) {
            view.getResultArea().setText(service.ticketsResolved());
        } else if (report.equalsIgnoreCase("Open Tickets")) {
            view.getResultArea().setText(service.openTickets());
        } else if (report.equalsIgnoreCase("Technician Workload")) {
            view.getResultArea().setText(service.technicianWorkload());
        } else if (report.equalsIgnoreCase("Average Resolution Time")) {
			view.getResultArea().setText(service.averageResolutionTime());
        }else { 
        	AlertUtil.showError("Unknown report", "That report is not available");
        }
	}
}
