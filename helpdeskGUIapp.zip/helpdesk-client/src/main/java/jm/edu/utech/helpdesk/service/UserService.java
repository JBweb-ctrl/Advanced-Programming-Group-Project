package jm.edu.utech.helpdesk.service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import jm.edu.utech.helpdesk.model.User;
public class UserService {

	private static final UserService INSTANCE = new UserService();
	
	private final ObservableList<User> users = FXCollections.observableArrayList();
	//demo users
	private UserService() {
		users.add(new User("student1", "Student/Staff"));
		users.add(new User("abc", "Student/Staff"));
		users.add(new User("admin", "Administrator"));
	}
	
	public static UserService getInstance() {
		return INSTANCE;
	}
	//returns the list of users the table has
	public ObservableList<User> getUsers(){
		return users;
	}
	//admin can add a user
	public synchronized boolean addUser(String username, String role) {
		for(User user : users) {
			if(user.getUsername().equalsIgnoreCase(username)) {
				return false;
			}
		}
		users.add(new User(username, role));
		return true;
	}
	//part of the user login/logout step
	//gets roles of the user with a particular username
	public String getRole(String username) {
		for (User user : users) {
			if (user.getUsername().equalsIgnoreCase(username)) {
				return user.getRole();
			}
		}
		return null;
	}
	//admin can remove a user
	public synchronized void removeUser(User user) {
		users.remove(user);
	}
}
