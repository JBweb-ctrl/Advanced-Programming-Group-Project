package jm.edu.utech.helpdesk.controller;
import jm.edu.utech.helpdesk.model.Technician;
import jm.edu.utech.helpdesk.service.TechnicianService;
import jm.edu.utech.helpdesk.service.TicketService;
import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.view.ManageTechniciansView;
//controller for the manage techs screen
public class ManageTechniciansController {
	//screen the controller works with
	private final ManageTechniciansView view;
	private final String username;
	//shared services that have the techs and tickets
	private final TechnicianService service = TechnicianService.getInstance();
	private final TicketService ticketService = TicketService.getInstance();
	
	public ManageTechniciansController(ManageTechniciansView view, String username) {
		this.view = view;
		this.username = username;
		view.getTechnicianTable().setItems(service.getTechnicians());
		attachHandlers();
	}
	private void attachHandlers() {
		view.getAddButton().setOnAction(e-> handleAdd());
		view.getRemoveButton().setOnAction(e-> handleRemove());
		view.getBackButton().setOnAction(e-> SceneManager.showAdminDashboard(username));
	}
	//add technician
	private void handleAdd() {
		String newUsername = view.getUsernameField().getText().trim();
		
		if (newUsername.isEmpty()) {
			AlertUtil.showError("Incomplete", "Enter a username");
			return;
		}
		if (!service.addTechnician(newUsername)) {
			AlertUtil.showError("Duplicate technician", "Technician already exists");
			return;
		}
		view.getUsernameField().clear();
		
	}
	 private void handleRemove() {
	        Technician selected = view.getTechnicianTable().getSelectionModel().getSelectedItem();

	        if (selected == null) {
	            AlertUtil.showWarning("No technician selected", "Select a technician");
	            return;
	        }
	        if (!ticketService.getTicketsByTechnician(selected.getUsername()).isEmpty()) {
	            AlertUtil.showWarning("Cannot remove", "This technician still has tickets assigned");
	            return;
	        }

	        service.removeTechnician(selected);
	    }

}
