package jm.edu.utech.helpdesk.controller;

import jm.edu.utech.helpdesk.model.Ticket;
import jm.edu.utech.helpdesk.service.TicketService;
import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.view.TechnicianDashboardView;
import javafx.collections.FXCollections;
//handles tech dashboard
public class TechnicianDashboardController {

	 private final TechnicianDashboardView view;
	 private final String username;
//put tech tickets into table 
 public TechnicianDashboardController(TechnicianDashboardView view, String username) {
	        this.view = view;
	        this.username = username;
	        loadAssignedTickets();
	        attachHandlers();
	    }

 /*private void loadSampleTickets() {
 view.getTicketTable().setItems(FXCollections.observableArrayList(
         new Ticket(1L, "Wi-Fi down", "HIGH", "ASSIGNED", "2026-10-02"),
         new Ticket(2L, "Projector not working", "MEDIUM", "ASSIGNED", "2026-10-03"),
         new Ticket(3L, "Cannot reset password", "LOW", "IN_PROGRESS", "2026-10-04")
 ));
}*/
	    //fills the table with only assigned tickets
	 private void loadAssignedTickets() {
	       view.getTicketTable().setItems(FXCollections.observableArrayList(
	                TicketService.getInstance().getTicketsByTechnician(username)));
	    }
	 //whats happens when each button is pressed
private void attachHandlers() {
	        view.getLogoutButton().setOnAction(e -> SceneManager.showLogin());
	        view.getTicketTable().getSelectionModel().selectedItemProperty().addListener((obs, old, ticket) -> {
	            if (ticket != null) {
	        view.getStatusBox().setValue(ticket.getStatus());
	        view.getNotesArea().setText(ticket.getResolutionNotes() == null ? "" : ticket.getResolutionNotes());
	        view.getDescriptionArea().setText(ticket.getDescription() == null ? "" : ticket.getDescription());
	            }
	        });

	        view.getUpdateStatusButton().setOnAction(e -> handleUpdateStatus());
	        view.getResolveButton().setOnAction(e -> handleResolve());
	        view.getChangePasswordButton().setOnAction(e -> SceneManager.showChangePassword(username));
	    }
//changes the selected ticket to the status chosen
	  private void handleUpdateStatus() {
	        Ticket ticket = view.getTicketTable().getSelectionModel().getSelectedItem();
	        String status = view.getStatusBox().getValue();

	        if (ticket == null) {
	            AlertUtil.showWarning("No ticket selected", "Select a ticket");
	            return;
	        }
	        if (status == null) {
	            AlertUtil.showWarning("No status selected", "Choose a status");
	            return;
	        }
	        TicketService.getInstance().updateStatus(ticket, status);
	        view.getTicketTable().refresh();
	    }
//saves notes and marks ticket as resolved
private void handleResolve() {
	        Ticket ticket = view.getTicketTable().getSelectionModel().getSelectedItem();
	        String notes = view.getNotesArea().getText().trim();

	        if (ticket == null) {
	            AlertUtil.showWarning("No Ticket selected", "Select a ticket");
	            return;
	        }
	        if (notes.isEmpty()) {
	            AlertUtil.showWarning("Missing notes", "Add notes");
	            return;
	        }
			TicketService.getInstance().resolveTicket(ticket, notes);;
	        ticket.setStatus("RESOLVED");
	        view.getStatusBox().setValue("RESOLVED");
	        view.getTicketTable().refresh();
	        AlertUtil.showInfo("Resolved", "Ticket " + ticket.getId() + " resolved.");
	    }
}
