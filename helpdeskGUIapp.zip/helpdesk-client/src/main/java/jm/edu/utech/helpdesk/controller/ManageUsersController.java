package jm.edu.utech.helpdesk.controller;
import jm.edu.utech.helpdesk.model.User;
import jm.edu.utech.helpdesk.service.UserService;
import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.view.ManageUsersView;
//handles the manage users screen for admin

public class ManageUsersController {

	private final ManageUsersView view;
	private final String username;
	private final UserService service = UserService.getInstance();
	
	public ManageUsersController(ManageUsersView view, String username) {
        this.view = view;
        this.username = username;
        view.getUserTable().setItems(service.getUsers());
        attachHandlers();
	} 
	//what happens when each button is clicked
	private void attachHandlers() {
		view.getAddButton().setOnAction(e -> handleAdd());
        view.getRemoveButton().setOnAction(e -> handleRemove());
        view.getBackButton().setOnAction(e -> SceneManager.showAdminDashboard(username));
	}
	private void handleAdd() {
        String newUsername = view.getUsernameField().getText().trim();
        String role = view.getRoleBox().getValue();

        if (newUsername.isEmpty() || role == null) {
            AlertUtil.showError("Incomplete", "Enter username and choose a role");
            return;
        }
        if (!service.addUser(newUsername, role)) {
            AlertUtil.showError("Duplicate Account", "That username already exists");
            return;
        }

        //empty the form so it is ready for the next user.
        view.getUsernameField().clear();
        view.getRoleBox().setValue(null);
    }

    // admin can remove a selected user.
    private void handleRemove() {
        User selected = view.getUserTable().getSelectionModel().getSelectedItem();

        if (selected == null) {
            AlertUtil.showWarning("No user selected", "Select a user");
            return;
        }
        if (selected.getUsername().equalsIgnoreCase(username)) {
            AlertUtil.showWarning("Cannot remove", "You cannot remove your own account");
            return;
        }

    service.removeUser(selected);
}
}
