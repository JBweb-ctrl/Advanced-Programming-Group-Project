package jm.edu.utech.helpdesk.controller;

import jm.edu.utech.helpdesk.model.Comment;
import jm.edu.utech.helpdesk.model.Ticket;
import jm.edu.utech.helpdesk.service.TicketService;
import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.view.UserDashboardView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
//controller that handles the user dashboard
public class UserDashboardController {
	//the screeen the controller needs
    private final UserDashboardView view;
    private final String username;
    //used the service that has all the tickets
    private final TicketService service = TicketService.getInstance();
    //the users tickets
    private final ObservableList<Ticket> tickets;
    
    private Ticket editingTicket;
    //load the user tickets into the table 
    public UserDashboardController(UserDashboardView view, String username) {
        this.view = view;
        this.username = username;
        this.tickets = FXCollections.observableArrayList(service.getTicketsByUser(username));
        view.getTicketTable().setItems(tickets);
        attachHandlers();
    }
  //what happens when each button is pressed
    private void attachHandlers() {
        view.getLogoutButton().setOnAction(e -> SceneManager.showLogin());
        view.getSubmitButton().setOnAction(e -> handleSubmit());
        view.getAddCommentButton().setOnAction(e -> handleAddComment());
        view.getTicketTable().getSelectionModel().selectedItemProperty().addListener((obs, old, ticket) -> showDetails(ticket));
        view.getEditButton().setOnAction(e -> handleEdit());
        view.getSaveButton().setOnAction(e -> handleSave());
        view.getCloseButton().setOnAction(e -> handleClose());
        view.getReopenButton().setOnAction(e -> handleReopen());
        view.getChangePasswordButton().setOnAction(e -> SceneManager.showChangePassword(username));
    }
//show selected ticket details
    private void showDetails(Ticket ticket) {
        if (ticket == null) {
            view.getDetailsArea().clear();
            view.getResolutionArea().clear();
            view.getCommentList().getItems().clear();
            return;
        }
        view.getDetailsArea().setText(ticket.getDescription() == null ? "" : ticket.getDescription());
        view.getResolutionArea().setText(ticket.getResolutionNotes() == null ? "" : ticket.getResolutionNotes());
        view.getCommentList().setItems( FXCollections.observableArrayList(ticket.getComments()));
    }
//check the form and makes a new user ticket
    private void handleSubmit() {
        String subject = view.getSubjectField().getText().trim();
        String description = view.getDescriptionField().getText().trim();
        String priority = view.getPriorityBox().getValue();

        if (subject.isEmpty() || description.isEmpty() || priority == null) {
            AlertUtil.showError("Incomplete", "Please enter a subject, description and priority");
            return;
        }

        Ticket ticket = service.createTicket(subject, description, priority, username);
        tickets.add(ticket);
        editingTicket = null;
        view.getSubjectField().clear();
        view.getDescriptionField().clear();
        view.getPriorityBox().setValue(null);
        AlertUtil.showInfo("Ticket submitted", "Ticket " + ticket.getId() + " created.");
    }
    //add a comment to the ticket
    private void handleAddComment() {
        Ticket ticket = view.getTicketTable().getSelectionModel().getSelectedItem();
        String text = view.getCommentField().getText().trim();

        if (ticket == null) {
            AlertUtil.showError("No Ticket selected", "Select a ticket");
            return;
        }
        if (text.isEmpty()) {
            AlertUtil.showError("Empty comment", "Write a comment.");
            return;
        }

        //String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        Comment comment = new Comment(username, text, text); //now was here
        ticket.getComments().add(comment);
        view.getCommentList().getItems().add(comment);
        view.getCommentField().clear();
    }
    //edit a selected ticket, cannot edit a closed ticket
    private void handleEdit() {
    	Ticket ticket = view.getTicketTable().getSelectionModel().getSelectedItem();
    	if (ticket == null) {
    		AlertUtil.showError("No ticket slected", "Select a ticket");
    		return;
    	}
    	if ("CLOSED".equals(ticket.getStatus())) {
    		AlertUtil.showError("Ticket closed", "Cannot edit");
    		return;
    	}
    	editingTicket = ticket;
    	view.getSubjectField().setText(ticket.getSubject());
    	view.getPriorityBox().setValue(ticket.getPriority());
        view.getDescriptionField().setText(ticket.getDescription());
    }
    //save the details to the ticket being edited
    private void handleSave() {
    	if (editingTicket == null) {
    		AlertUtil.showError("Nothing to save", "Click edit selected first");
    		return;
    	}
    	String subject = view.getSubjectField().getText().trim();
    	String description= view.getDescriptionField().getText().trim();
    	String priority = view.getPriorityBox().getValue();
    	
    	if (subject.isEmpty() || description.isEmpty() || priority == null) {
    		AlertUtil.showError("Incomplete","Please enter a subject, description and priority");
    		return;
    	}
    	service.updateTicket(editingTicket, subject, description, priority);
    	//refresh the table everytime you update the subject
    	view.getTicketTable().refresh();
    	showDetails(editingTicket);
    	//empty the form
    	view.getSubjectField().clear();
        view.getDescriptionField().clear();
        view.getPriorityBox().setValue(null);
        AlertUtil.showInfo("Ticket updated", "Ticket " + editingTicket.getId() + " updated.");
        editingTicket = null;
    	
    }
    //close the ticket
    private void handleClose() {
        Ticket ticket = view.getTicketTable().getSelectionModel().getSelectedItem();

        if (ticket == null) {
            AlertUtil.showError("No Ticket selected", "Select a ticket");
            return;
        }
        if ("CLOSED".equals(ticket.getStatus())) {
            AlertUtil.showError("Already closed", "Ticket is already closed");
            return;
        }

        service.closeTicket(ticket);
        view.getTicketTable().refresh();
        AlertUtil.showInfo("Ticket closed", "Ticket " + ticket.getId() + " closed");
    }
    //reopen a ticket
    private void handleReopen() {
        Ticket ticket = view.getTicketTable().getSelectionModel().getSelectedItem();

        if (ticket == null) {
            AlertUtil.showError("No Ticket selected", "Select a ticket");
            return;
        }
        if (!"CLOSED".equals(ticket.getStatus()) && !"RESOLVED".equals(ticket.getStatus())) {
            AlertUtil.showError("Cannot reopen", "Only resolved or closed tickets can be reopened");
            return;
        }

        service.reopenTicket(ticket);
        view.getTicketTable().refresh();
        AlertUtil.showInfo("Ticket reopened", "Ticket " + ticket.getId() + " reopened");
}
}
