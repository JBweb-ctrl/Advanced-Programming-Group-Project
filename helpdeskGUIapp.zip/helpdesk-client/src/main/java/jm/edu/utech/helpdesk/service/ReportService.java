package jm.edu.utech.helpdesk.service;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import jm.edu.utech.helpdesk.model.Ticket;

//this is for report endpoint 
//the reports the admins can generate 
public class ReportService {

	private static final ReportService INSTANCE = new ReportService();
	//services the have the data that the reports are built from
	private final TicketService ticketService = TicketService.getInstance();
	private final TechnicianService technicianService = TechnicianService.getInstance();
	
	private ReportService() {}
	
	public static ReportService getInstance() {
		return INSTANCE;
		}
	//all the tickets the users submitted
	public String ticketsSubmitted() {
		List<Ticket> all = ticketService.getAllTickets();
	
	//collect each user name
	List<String>users = new ArrayList<>();
	for (Ticket t : all) {
		if (!users.contains(t.getSubmittedBy())) {
			users.add(t.getSubmittedBy());
		}
	}
	String report = "TICKETS SUBMITTED\nTotal: " + all.size() + "\n";
	
	//ticket count for each user 
	for (String user : users) {
		int count = 0;
		for (Ticket t : all) {
			if (user.equals(t.getSubmittedBy())) {
				count++;
			}
		}
		report += user + ": " + count + "\n";
	}
	return report;
}

	//resolved tickets
	public String ticketsResolved() {
		String lines = "";
		int count = 0;
		
		for (Ticket t : ticketService.getAllTickets()) {
			if ("RESOLVED".equals(t.getStatus())) {
				count ++;
				lines += "#" + t.getId() + " " + t.getSubject() + " (" + t.getAssignedTechnician() + ")\n";
			}
		}
		return "TICKETS RESOLVED\nTotal: " + count + "\n" + lines;
	}
	//open tickets
	public String openTickets() {
		String lines = "";
		int count = 0;
		
		for(Ticket t : ticketService.getAllTickets() ) {
			if (isOpen(t)) {
				count ++;
				lines += "#" + t.getId() + "  " + t.getSubject() + "  [" + t.getStatus() + "]\n";
			}
		}
		return "OPEN TICKETS\nTotal: " + count + "\n" + lines;
	}
	//technician workload (how many tickets each tech has and total)
	public String technicianWorkload() {
		String report = "TECHNICIAN WORKLOAD\n";
		
		for (String technician : technicianService.getTechnicianNames()) {
			int open = 0;
			int total = 0;
			
			for (Ticket t : ticketService.getAllTickets()) {
				if (technician.equalsIgnoreCase(t.getAssignedTechnician())) {
					total ++;
					if (isOpen(t)) {
						open++;
					}
				}
			}
			report += technician + ": " + open + " open & " + total + " assigned in total\n";
		}
		return report;
	}
	private boolean isOpen(Ticket ticket) {
		return !"RESOLVED".equals(ticket.getStatus()) && !"CLOSED".equals(ticket.getStatus());
	}
	//used to get the report of the average time it takes to resolves a ticket
	public String averageResolutionTime() {
		String lines = "";
		int count = 0;
		long totalDays = 0;

		for (Ticket t : ticketService.getAllTickets()) {
			boolean finished = "RESOLVED".equals(t.getStatus()) || "CLOSED".equals(t.getStatus());

			if (finished && t.getResolvedDate() != null) {
				long days = ChronoUnit.DAYS.between(
						LocalDate.parse(t.getCreationDate()), LocalDate.parse(t.getResolvedDate()));
				totalDays += days;
				count++;
				lines += "#" + t.getId() + "  " + t.getSubject() + "  " + days + " day(s)\n";
			}
		}

		if (count == 0) {
			return "AVERAGE RESOLUTION TIME\nNo resolved tickets yet";
		}

		double average = (double) totalDays / count;
		return "AVERAGE RESOLUTION TIME\nAverage: " + String.format("%.1f", average)
				+ " day(s) over " + count + " ticket(s)\n" + lines;
	}
}
