package jm.edu.utech.helpdesk.controller;

import jm.edu.utech.helpdesk.model.Ticket;
import jm.edu.utech.helpdesk.service.TicketService;
import jm.edu.utech.helpdesk.service.TechnicianService;
import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.view.AdminDashboardView;
import javafx.collections.FXCollections;
import java.time.LocalDate;
import java.util.List;
//handles the admin dashboard, lets admin assign tickets to techs
public class AdminDashboardController {
	//screen thee controller needs
    private final AdminDashboardView view;
    private final String username;  
    //service that stores all tickets
    private final TicketService service = TicketService.getInstance();
    //loads every
    public AdminDashboardController(AdminDashboardView view, String username) {
        this.view = view;
        this.username = username;
        loadAllTickets();
        //updates the admin dropdown after you add a technician so you can select and assign them to a task
        view.getTechnicianBox().getItems().setAll(TechnicianService.getInstance().getTechnicianNames());
        //search
        view.getSearchTechnician().getItems().setAll(TechnicianService.getInstance().getTechnicianNames());
        attachHandlers();
    }
    //gets all the tickets in the table
    private void loadAllTickets() {
        view.getTicketTable().setItems(FXCollections.observableArrayList(service.getAllTickets()));
    }
  //whats happens when each button is pressed
    private void attachHandlers() {
        view.getLogoutButton().setOnAction(e -> SceneManager.showLogin());
        view.getAssignButton().setOnAction(e -> handleAssign());
        //button to change password
        view.getChangePasswordButton().setOnAction(e -> SceneManager.showChangePassword(username));
        //button to manage a user
        view.getManageUsersButton().setOnAction(e -> SceneManager.showManageUsers(username));
        //button to manage a tech
        view.getManageTechsButton().setOnAction(e -> SceneManager.showManageTechnicians(username));
        //button to show a report
        view.getReportsButton().setOnAction(e -> SceneManager.showReports(username));
        //show selected ticket description
        view.getTicketTable().getSelectionModel().selectedItemProperty().addListener((obs, old, ticket) -> {
            if (ticket == null) {
                view.getDescriptionArea().clear();
            } else {
                view.getDescriptionArea().setText(
                        ticket.getDescription() == null ? "" : ticket.getDescription());
            }
        });
        //button that actually does searching
        view.getSearchButton().setOnAction(e -> handleSearch());
        //button that empties the fields
        view.getClearButton().setOnAction(e -> handleClear());
        
    }
//assign tickets to techs and handle errors
    private void handleAssign() {
        Ticket ticket = view.getTicketTable().getSelectionModel().getSelectedItem();
        String technician = view.getTechnicianBox().getValue();

        if (ticket == null) {
            AlertUtil.showError("No ticket selected", "Select a ticket");
            return;
        }
        if (technician == null) {
            AlertUtil.showError("No technician selected", "Choose a tech");
            return;
        }

        service.assignTicket(ticket, technician);
        //new tech and status show after refresh
        view.getTicketTable().refresh();
        AlertUtil.showInfo("Ticket Assigned", "Ticket" + ticket.getId() + "assigned to " + technician);
    }
  //looks for matching tickets in the search 
    private void handleSearch() {
        String id = view.getSearchId().getText().trim();
        String user = view.getSearchUser().getText().trim();
        String technician = valueOrEmpty(view.getSearchTechnician().getValue());
        String status = valueOrEmpty(view.getSearchStatus().getValue());
        String priority = valueOrEmpty(view.getSearchPriority().getValue());
        LocalDate from = view.getFromDate().getValue();
        LocalDate to = view.getToDate().getValue();

    if (!id.isEmpty()) {
        try {
            Integer.parseInt(id);
        } catch (NumberFormatException exception) {
            AlertUtil.showError("Invalid", "Ticket ID must be a whole number");
            return;
        }
    }
    if (from != null && to != null && from.isAfter(to)) {
        AlertUtil.showError("Invalid dates", "The From date cannot be after the To date.");
        return;
    }
    List<Ticket> results = service.searchTickets(id, user, technician, status, priority, from == null ? "" : from.toString(), to == null ? "" : to.toString());

    view.getTicketTable().setItems(FXCollections.observableArrayList(results));
}
    //empties the search boxes if you had a specific filter set up
    private void handleClear() {
        view.getSearchId().clear();
        view.getSearchUser().clear();
        view.getSearchTechnician().setValue(null);
        view.getSearchStatus().setValue(null);
        view.getSearchPriority().setValue(null);
        view.getFromDate().setValue(null);
        view.getToDate().setValue(null);
        loadAllTickets();
    }
    private String valueOrEmpty(String value) {
        return value == null ? "" : value;
    }
}