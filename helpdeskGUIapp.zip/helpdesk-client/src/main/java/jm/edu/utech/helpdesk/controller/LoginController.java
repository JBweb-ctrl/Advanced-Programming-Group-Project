package jm.edu.utech.helpdesk.controller;

import jm.edu.utech.helpdesk.util.AlertUtil;
import jm.edu.utech.helpdesk.util.SceneManager;
import jm.edu.utech.helpdesk.service.TechnicianService;
import jm.edu.utech.helpdesk.service.UserService;
import jm.edu.utech.helpdesk.util.AlertUtil;

import jm.edu.utech.helpdesk.view.LoginView;
//handles login screen checks the fields then send the user to the right place
public class LoginController {
	
	//login screen the controller needs
	private final LoginView view;
	
	public LoginController (LoginView view) {
	this.view = view;
	attachHandlers();
	}
	//whats happens when each button is pressed
	private void attachHandlers() {
		view.getLoginButton().setOnAction( e -> handleLogin());
		view.getPasswordField().setOnAction(e -> handleLogin());
		//view.getRegisterButton().setOnAction( e->  AlertUtil.showInfo("Login", "Register"));
		view.getRegisterButton().setOnAction(e -> SceneManager.showRegister());
	}
	//reads the info entered in the view
	private void handleLogin() {
		String username = view.getUsernameField().getText().trim();
		String password = view.getPasswordField().getText();
		
		view.getErrorLabel().setText("");
		//checks that both fields are filled in
		if (username.isEmpty() || password.isEmpty()) {
			view.getErrorLabel().setText("Please enter username and password");
			return;
		}
	//Temporary: only usernames that exist can log in 
		//
		//
		if (UserService.getInstance().getRole(username) == null && !TechnicianService.getInstance().exists(username)) {
			AlertUtil.showError("Invalid login details", "Username or password is incorrect");
			return;
		}
		/*AlertUtil.showInfo("Login", "Validation passed for: " + username);
		/SceneManager.showUserDashboard(username);
		Temporary
		if (username.toLowerCase().startsWith("tech")) {
		    SceneManager.showTechnicianDashboard(username);
		}else if (username.equalsIgnoreCase("admin")) {
			SceneManager.showAdminDashboard(username);
		} else {
		    SceneManager.showUserDashboard(username);
		}*/
		//scenemanager shows the dashboard based on the username/user that logs in
        SceneManager.showDashboard(username);
		
	}
}
