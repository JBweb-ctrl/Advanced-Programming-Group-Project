package jm.edu.utech.library.persistence;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class JpaUtil {
   private static final EntityManagerFactory FACTORY =
		   Persistence.createEntityManagerFactory("libraryPU");
   
   public static EntityManager createEntityManager() {
	   return FACTORY.createEntityManager();
   }
   public static void close() {
	   if (FACTORY.isOpen()) FACTORY.close();
   }
   private JpaUtil() {}
}
