package jm.edu.utech.library.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "technician")
public class Technician {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "technician_id")
	private Long id;
	
	@Column(nullable = false, length = 50)
	private String name;
	
	@Column(nullable =false, length =50)
	private String position;
	
	@Column(name = "phone_number",nullable= false, length =20)
	private String phoneNumber;
	
	@JsonIgnore
	@OneToMany(mappedBy = "technician")
	private List <Ticket> ticket = new ArrayList<>();
	
	protected Technician() {}

	public List<Ticket> getTicket() {
		return ticket;
	}

	public void setTicket(List<Ticket> ticket) {
		this.ticket = ticket;
	}

	public Technician(Long id, String name, String position, String phoneNumber, List<Ticket> ticket) {
		super();
		this.id = id;
		this.name = name;
		this.position = position;
		this.phoneNumber = phoneNumber;
		this.ticket = ticket;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
	