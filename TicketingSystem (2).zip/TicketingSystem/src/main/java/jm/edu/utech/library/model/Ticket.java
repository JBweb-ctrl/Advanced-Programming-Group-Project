package jm.edu.utech.library.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "ticket")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ticket_number")
	private Long id;
	
	@Column(nullable = false, length = 150)
	private String subject;
	
	@Column(nullable =false, length =200)
	private String description;
	
	@Column(name = "creation_date", nullable = false)
	private date creationDate;
	
	@Column(nullable =false, length =10)
	private String priority;
	
	@Column(nullable =false, length =15)
	private String status;
	
	@Column(nullable =false, length =1000)
	private String resolution_notes;
	
	@ManyToOne(Optional = false)
	@JoinColumn(name ="user_id", nullable = false)
	private User user;
	
	@ManyToOne
	@JoinColumn(name ="technician_id")
	private Technician technician;
	
	 @JsonIgnore
	    @OneToMany(mappedBy = "ticket", cascade = CascadeType.ALL, orphanRemoval = true)
	    private List<Comment> comments = new ArrayList<>();
	    
	protected Ticket() {}

	public Ticket(Long id, String subject, String description, date creationDate, String priority, String status,
			String resolution_notes, User user, Technician technician, List<Comment> comments) {
		super();
		this.id = id;
		this.subject = subject;
		this.description = description;
		this.creationDate = creationDate;
		this.priority = priority;
		this.status = status;
		this.resolution_notes = resolution_notes;
		this.user = user;
		this.technician = technician;
		this.comments = comments;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(date creationDate) {
		this.creationDate = creationDate;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResolution_notes() {
		return resolution_notes;
	}

	public void setResolution_notes(String resolution_notes) {
		this.resolution_notes = resolution_notes;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Technician getTechnician() {
		return technician;
	}

	public void setTechnician(Technician technician) {
		this.technician = technician;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	
	


}