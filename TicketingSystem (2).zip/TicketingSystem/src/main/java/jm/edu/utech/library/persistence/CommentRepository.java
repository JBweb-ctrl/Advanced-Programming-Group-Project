package jm.edu.utech.library.persistence;
import java.util.List;
import java.util.Optional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jm.edu.utech.library.model.Comment;

public class CommentRepository {
	 public Comment save(Comment comment) {
	        EntityManager em = JpaUtil.createEntityManager();
	        EntityTransaction tx = em.getTransaction();

	        try {
	            tx.begin();
	            Comment saved = comment.getId() == null
	                ? persistNew(em, comment) : em.merge(comment);
	            tx.commit();
	            return saved;
	        } catch (RuntimeException ex) {
	            if (tx.isActive()) tx.rollback();
	            throw ex;
	        } finally {
	            em.close();
	        }
	    }

	    private Comment persistNew(EntityManager em, Comment comment) {
	        em.persist(comment);
	        return comment;
	    }
	 public Optional<Comment> findById(Long id) {
	     EntityManager em = JpaUtil.createEntityManager();
	     try {
	         return Optional.ofNullable(em.find(Comment.class, id));
	     } finally {
	         em.close();
	     }
	 }

	 public List<Comment> findAll() {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        return em.createQuery(
		                "select c from Comment c order by c.id", Comment.class)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}

		public List<Comment> search(String text) {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        String pattern = "%" + text.trim().toLowerCase() + "%";
		        return em.createQuery(
		                "select c from Comment c " +
		                "where lower(c.text) like :pattern " +
		                "or cast(c.ticket.id as string) like :pattern" +
		                "order by c.id", Comment.class)
		                .setParameter("pattern", pattern)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}
		
		public List<Comment> findByTicketNumber(Long ticketNumber) {
		    EntityManager em = JpaUtil.createEntityManager();
		    try {
		        return em.createQuery(
		                "select c from Comment c " +
		                "where c.ticket.id = :ticketNumber " +
		                "order by c.id", Comment.class)
		                .setParameter("ticketNumber", ticketNumber)
		                .getResultList();
		    } finally {
		        em.close();
		    }
		}

	 public void delete(Long id) {
	     EntityManager em = JpaUtil.createEntityManager();
	     EntityTransaction tx = em.getTransaction();
	     try {
	         tx.begin();
	         Comment managed = em.find(Comment.class, id);
	         if (managed != null) em.remove(managed);
	         tx.commit();
	     } catch (RuntimeException ex) {
	         if (tx.isActive()) tx.rollback();

	         throw ex;
	     } finally {
	         em.close();
	     }
	 }
}
