package jm.edu.utech.library.model;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "comment")
public class Comment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "comment_id")
	private Long id;
	
	@JsonIgnore
	@ManyToOne(optional = false)
	@Column(name = "ticket_id", nullable = false)
	private Ticket ticket;
	
	@Column(nullable =false, length =1000)
	private String text;
	
	@CreationTimestamp
	@Column(name = "comment_date", nullable =false)
	private LocalDateTime commentDate;
	
	
	protected Comment() {}

	public Comment(Long id, Ticket ticket, String text, LocalDateTime commentDate) {
		super();
		this.id = id;
		this.ticket = ticket;
		this.text = text;
		this.commentDate = commentDate;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Ticket getTicket() {
		return ticket;
	}


	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}


	public String getText() {
		return text;
	}


	public void setText(String text) {
		this.text = text;
	}


	public LocalDateTime getCommentDate() {
		return commentDate;
	}


	public void setCommentDate(LocalDateTime commentDate) {
		this.commentDate = commentDate;
	}




}

	
	

	